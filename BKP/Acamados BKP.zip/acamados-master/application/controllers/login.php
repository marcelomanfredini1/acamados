<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {
	
	public function __construct() {
			parent::__construct();
	}	
	public function index(){
		$this->load->view('login');	
	}
	public function Validar() {
		$this->form_validation->set_rules('nome','nome','trim|required|callback__check_login');
			if($this->form_validation->run()==TRUE){
				$session = array('logado' => 1);
				$this->session->set_userdata($session);
				/*$dados = array (
					'tela' => 'inicio',
				);
				$this->load->view('index',$dados);
				 * 
				 */
				 redirect('index');
			}else{
				$this->load->view('login');
			}
	}
	public function logoff(){
		$this->session->sess_destroy();
		redirect('login');
	}
	public function _check_login($nome) {
		if($this->input->post('senha')){
			$user = $this->model_users->get_usuario($nome,$this->input->post('senha'));
				if($user) return true;
		}
		$this->form_validation->set_message('_check_login','Usuários / Senha Errado(s)');
		return false;
	}
}
			/*
		$this->form_validation->set_rules('nome','Nome','trim|required|callback__check_login');
		$this->form_validation->set_rules('senha','Senha','trim|required');		
		if($this->form_validation->run()==TRUE){
			//chamar um aviso na view...
			$dados_login = array(
			'nome_usuario' => $nome,
			'logado' => 1
			);
			$this->session->userdata($dados_login);
			//redirect('acamados');
			} else {
			$dados = array(
				'titulo' => 'Sistema de Acamados',
				'tela' => 'index'
				);		
			$this->load->view('index',$dados);
			}
			
	}

	public function _check_login($nome) {
		
		if($this->input->post('senha'))
		{
			$user = $this->model_users->get_usuario($nome,$this->input->post('senha'));

			if(isset($user)){
				return true;
			}else{
				return false;
			}

		}
		$this->form_validation->set_message('_check_login','Usuários / Senha Errado(s)');
		return false;
			 */