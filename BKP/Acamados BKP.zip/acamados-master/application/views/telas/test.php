<?php 
echo $dd;