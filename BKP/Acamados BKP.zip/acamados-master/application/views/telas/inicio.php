			<div class="titulo">
			<figure class="logo">
				<div align="center">
				<img src="<?php echo base_url(); ?>/padrao/img/bandeira.gif" alt="Prefeitura de Guarulhos">
				</div>
				</figure>
			</div>