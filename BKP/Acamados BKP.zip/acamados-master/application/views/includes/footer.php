</div>
<!-- Initialize the plugin: -->
<script type="text/javascript">
$(document).ready(function() {
    $('.multiselect').multiselect();
});
</script>
</body>
	  <footer class="footer">
      <div class="container">
        <p class="pull-right"><a href="#">Voltar ao topo</a></p>
        			<p>Sistema Desenvonvido Pelo: DTTICS <br> Divisão Técnica em Telecomunicações, Informática e Comunicação na Saúde</p>
        			<!--Colocar o link do manual quando estiver pronto.-->
        			<p class="pull-right"><a href="http://www.inserir-link.com.br"><button class="btn btn-primary">MANUAL</button></a></p>
        			<br> Secretaria da Saúde - Ramal: 5150 - Falar com: Eduardo dos Santos ou Ruan Victor. <br> E-mail: <a href="mailto:eduardo.linkcon@gmail.com">eduardo.linkcon@gmail.com</a>  ou <a href="mailto:ruansvictor@gmail.com">ruansvictor@gmail.com.</a>
        </ul>
      </div>
    </footer>
   </body>
</html>