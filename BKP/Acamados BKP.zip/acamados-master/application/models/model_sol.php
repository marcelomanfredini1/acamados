<?php if (! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 
 */
class Model_Sol extends CI_Model {
	
	function __construct() {
		parent::__construct();
	}
	public function inserir($dados=NULL,$insumos=NULL)
	{
		if($dados!=null){
			if($insumos!=null){
				$this->db->insert('solicitacao_insumos',$dados);
				if ($this->addInsumos($insumos)) {
					$this->session->set_flashdata('cadastrook',"<div class=\"alert alert-block alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button><p> Solicitação feita com sucesso </p></div>");
					redirect('solicitacoes/destroy');
				} else {
					$this->session->set_flashdata('cadastrook',"<div class=\"alert alert-block alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">x</button><p> $string </p></div>");
					redirect('solicitacoes/erro');
				}
						
			}
		}
	}
	public function addInsumos($dados =Null)
	{
		$query = $this->db->query('SELECT id_sol_insumos FROM solicitacao_insumos ORDER BY  id_sol_insumos DESC LIMIT 1');
		$id_sol_insumos = $query->row();
		foreach ($dados as $linha) {
				$id_sol_insumos_solicitacao_insumos = $id_sol_insumos->id_sol_insumos;
				$id_cad_insumos_cad_insumos = $linha['id_cad_insumos_cad_insumos'];
				$quantidade = $linha['quantidade'];
				$observacao = $linha['observacao'];
				$sql = "INSERT INTO insumos_solicitados (quantidade, id_cad_insumos_cad_insumos, id_sol_insumos_solicitacao_insumos,observacao) 
        VALUES (".$this->db->escape($quantidade).", ".$this->db->escape($id_cad_insumos_cad_insumos).", ".$this->db->escape($id_sol_insumos_solicitacao_insumos).", ".$this->db->escape($observacao).")";
					$this->db->query($sql);
		}
		if ($this->db->affected_rows() == 0) {
			return false;
		} else {
			return TRUE;
		}
	}
	public function getInsumos($id = NULL)
	{
		return $this->db->query("SELECT * FROM v_insumo_solicitados WHERE id_sol_insumos_solicitacao_insumos=".$this->db->escape($id));
	}
	public function getSolicitacoById($id = NULL)
	{
		
		return $this->db->query("SELECT * FROM solicitacoes WHERE id=".$this->db->escape($id)." LIMIT 1");
	}
	public function getSolicitacoes()
	{
		return $this->db->get('solicitacoes');
	}
	public function getTipos(){
		return $this->db->get('tipo_solicitacao');
	}
	public function updateSol($dados=NULL, $condicao=null){
		if($dados!=NULL && $condicao != null):
			/*if ($insumos != null) {
				if ($this->updateInsumos($insumos)) {
					$this->db->update('solicitacao_insumos',$dados,array(id_sol_insumos=>$condicao));
					$this->session->set_flashdata('edicaook','Edição efetuada com sucesso');
					redirect("solicitacoes/editar/$condicao");
				} else {
					$this->session->set_flashdata('edicaook','Edição não efetuada algo deu errado');
					redirect("solicitacoes/editar/$condicao");
				}
			}*/
			$this->db->update('solicitacao_insumos',$dados,array(id_sol_insumos=>$condicao));
			$this->session->set_flashdata('edicaook','Edição efetuada com sucesso');
			redirect("solicitacoes/editar/$condicao");
		endif;
	}
	public function updateInsumos($dados=NULL){
		if($dados!=NULL && $condicao != null && $idsol != null):
			/*foreach ($dados as $linha) {
				$id_sol_insumos_solicitacao_insumos = $linha['id_sol_insumos_solicitacao_insumos'];
				$id_cad_insumos_cad_insumos = $linha['id_cad_insumos_cad_insumos'];
				$quantidade = $linha['quantidade'];
				$observacao = $linha['observacao'];
				$sql = "UPDATE insumos_solicitados SET quantidade=".$this->db->escape($quantidade).", observacao=".$this->db->escape($observacao)."
				WHERE id_cad_insumos_cad_insumos=".$this->db->escape($id_cad_insumos_cad_insumos)."
				AND id_sol_insumos_solicitacao_insumos=".$this->db->escape($id_sol_insumos_solicitacao_insumos).";";
				$this->db->query($sql);
			}*/
			$this->db->update('solicitacao_insumos',$dados,array(id_cad_insumos_cad_insumos=>$condicao,id_sol_insumos_solicitacao_insumos=>$idsol));
		endif;
		if ($this->db->affected_rows() == 0) {
			return false;
		} else {
			return TRUE;
		}
	}
	public function addInsumosWtId($dados=NULL, $id_sol_insumos_solicitacao_insumos='')
	{
		if($id_sol_insumos_solicitacao_insumos != ''){
			if($dados!=null){
				$this->db->insert('insumos_solicitados',$dados);
				return true;
			} else {
				return false;
			}
		}
	}
	public function getInsumo($id_cad_insumos_cad_insumos ='', $id_sol_insumos_solicitacao_insumos='')
	{
		if ($id_cad_insumos_cad_insumos !='' && $id_sol_insumos_solicitacao_insumos !='') {
			return $this->db->query("SELECT *  FROM v_insumo_solicitados
			 WHERE id_cad_insumos_cad_insumos=".$this->db->escape($id_cad_insumos_cad_insumos)."  
			 AND id_sol_insumos_solicitacao_insumos=".$this->db->escape($id_sol_insumos_solicitacao_insumos)." LIMIT 1");
		}
	}
}
